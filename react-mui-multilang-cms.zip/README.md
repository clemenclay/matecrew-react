# React + MUI + CMS (Multilenguaje)

Starter para conectar un front en React (MUI) a tu CMS headless.

## 🚀 Correr local
```bash
npm install
cp .env.sample .env
# Editá .env con tu URL, Project ID y Token
npm run dev
```

## 🔧 Variables de entorno
- `VITE_CMS_BASE_URL` (ej: `https://cms.speednova.com`)
- `VITE_CMS_PROJECT_ID` (ej: `1ab33be1-8aba-453d-b365-64f4c3590696`)
- `VITE_CMS_TOKEN` → valor exacto para el header **Authorization** (si tu API requiere `Bearer ...`, incluí el prefijo en esta variable)
- `VITE_DEFAULT_LANG` → `es` o `en`

## 🧩 Endpoints usados
- `GET /api/settings` (single) — para brand y redes
- `GET /api/collections` — listado de colecciones
- `GET /api/posts?limit=6&sort=published_at,DESC&locale=es` — últimos posts

Estos headers se envían en cada request:
- `Accept: application/json`
- `project-id: <PROJECT_ID>`
- `Authorization: <TOKEN tal cual>`

> Ajustá `locale` si tu CMS usa `Accept-Language` u otro mecanismo.

## 📂 Estructura
```
src/
  App.jsx
  main.jsx
  components/
    LanguageMenu.jsx
    PostCard.jsx
    PostsGrid.jsx
  services/
    cms.js
```

## ✅ Notas
- MUI instalado según guía oficial.
- No se usa router para simplicidad.
- `derivePostList` intenta mapear formatos comunes del payload (basado en tus ejemplos).
