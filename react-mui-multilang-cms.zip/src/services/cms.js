const BASE_URL = import.meta.env.VITE_CMS_BASE_URL?.replace(/\/$/, '') || 'https://cms.speednova.com'
const PROJECT_ID = import.meta.env.VITE_CMS_PROJECT_ID || ''
const TOKEN = import.meta.env.VITE_CMS_TOKEN || ''
const DEFAULT_LANG = import.meta.env.VITE_DEFAULT_LANG || 'es'

function buildHeaders() {
  const headers = {
    'Accept': 'application/json',
    'project-id': PROJECT_ID,
  }
  if (TOKEN) {
    headers['Authorization'] = TOKEN // IMPORTANT: include 'Bearer ' in the env var IF your API needs it
  }
  return headers
}

async function httpGet(path, { signal, params = {} } = {}) {
  const url = new URL(`${BASE_URL}${path}`)
  Object.entries(params).forEach(([k, v]) => {
    if (v !== undefined && v !== null && v !== '') url.searchParams.set(k, v)
  })
  const res = await fetch(url.toString(), { headers: buildHeaders(), signal })
  if (!res.ok) {
    const text = await res.text()
    throw new Error(`HTTP ${res.status} ${res.statusText}: ${text}`)
  }
  return res.json()
}

export async function fetchSettings({ signal, locale = DEFAULT_LANG } = {}) {
  // Fallback to /api/settings per Postman collection
  return httpGet('/api/settings', { signal, params: { locale } })
}

export async function fetchCollections({ signal } = {}) {
  return httpGet('/api/collections', { signal })
}

export async function fetchPosts({ signal, locale = DEFAULT_LANG, limit = 6, sort = 'published_at,DESC' } = {}) {
  return httpGet('/api/posts', { signal, params: { limit, sort, locale } })
}

export function derivePostList(json) {
  // Try common shapes: {data: []} or []
  const arr = Array.isArray(json) ? json : (Array.isArray(json?.data) ? json.data : [])
  return arr.map(p => {
    // Normalize a few common fields found in example payloads
    const title = p.fields?.title || p.title || 'Sin título'
    const excerpt = p.fields?.excerpt || p.excerpt || ''
    const slug = p.fields?.slug || p.slug || p.fields?.url || ''
    const img = (() => {
      const ci = p.fields?.['cover-image'] || p['cover-image'] || p.cover_image || []
      if (Array.isArray(ci) && ci.length>0) return ci[0].url || ci[0].thumbnail_url
      return null
    })()
    const locale = p.locale || p.fields?.locale
    const published_at = p.published_at || p.fields?.published_at
    return { title, excerpt, slug, img, locale, published_at, raw: p }
  })
}
