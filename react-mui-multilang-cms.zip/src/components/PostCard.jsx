import React from 'react'
import { Card, CardActionArea, CardContent, CardMedia, Typography, Chip, Stack } from '@mui/material'

export default function PostCard({ post }) {
  return (
    <Card elevation={2} sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      <CardActionArea sx={{ flexGrow: 1 }}>
        {post.img && (
          <CardMedia component="img" image={post.img} alt={post.title} sx={{ height: 180, objectFit: 'cover' }} />
        )}
        <CardContent>
          <Stack direction="row" spacing={1} sx={{ mb: 1 }}>
            {post.locale && <Chip size="small" label={post.locale.toUpperCase()} />}
            {post.published_at && <Chip size="small" variant="outlined" label={new Date(post.published_at).toLocaleDateString()} />}
          </Stack>
          <Typography gutterBottom variant="h6" component="div">
            {post.title}
          </Typography>
          {post.excerpt && (
            <Typography variant="body2" color="text.secondary">
              {post.excerpt}
            </Typography>
          )}
        </CardContent>
      </CardActionArea>
    </Card>
  )
}
