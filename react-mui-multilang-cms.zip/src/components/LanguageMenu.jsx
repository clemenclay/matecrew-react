import React from 'react'
import { IconButton, Menu, MenuItem, Tooltip } from '@mui/material'
import LanguageIcon from '@mui/icons-material/Language'

const DEFAULTS = ['es', 'en']

export default function LanguageMenu({ value, onChange, options = DEFAULTS }) {
  const [anchorEl, setAnchorEl] = React.useState(null)
  const open = Boolean(anchorEl)

  return (
    <>
      <Tooltip title={`Idioma: ${value}`}>
        <IconButton color="inherit" onClick={(e) => setAnchorEl(e.currentTarget)}>
          <LanguageIcon />
        </IconButton>
      </Tooltip>
      <Menu anchorEl={anchorEl} open={open} onClose={() => setAnchorEl(null)}>
        {options.map(opt => (
          <MenuItem
            key={opt}
            selected={opt === value}
            onClick={() => { onChange(opt); setAnchorEl(null) }}
          >
            {opt.toUpperCase()}
          </MenuItem>
        ))}
      </Menu>
    </>
  )
}
