import React from 'react'
import { Grid, Alert, CircularProgress, Box } from '@mui/material'
import { fetchPosts, derivePostList } from '../services/cms'
import PostCard from './PostCard'

export default function PostsGrid({ locale }) {
  const [loading, setLoading] = React.useState(true)
  const [error, setError] = React.useState(null)
  const [posts, setPosts] = React.useState([])

  React.useEffect(() => {
    const ctrl = new AbortController()
    setLoading(true); setError(null)
    fetchPosts({ signal: ctrl.signal, locale }).then(json => {
      setPosts(derivePostList(json))
    }).catch(err => {
      console.error(err)
      setError(err.message)
    }).finally(() => setLoading(false))
    return () => ctrl.abort()
  }, [locale])

  if (loading) return <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', py: 6 }}><CircularProgress /></Box>
  if (error) return <Alert severity="error">{error}</Alert>

  return (
    <Grid container spacing={2}>
      {posts.map((p, idx) => (
        <Grid item key={idx} xs={12} sm={6} md={4}>
          <PostCard post={p} />
        </Grid>
      ))}
    </Grid>
  )
}
