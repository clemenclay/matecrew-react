import React from 'react'
import {
  AppBar, Toolbar, Typography, Container, Box, IconButton, Link as MLink
} from '@mui/material'
import GitHubIcon from '@mui/icons-material/GitHub'
import LanguageMenu from './components/LanguageMenu'
import PostsGrid from './components/PostsGrid'
import { fetchSettings } from './services/cms'

export default function App() {
  const [lang, setLang] = React.useState(import.meta.env.VITE_DEFAULT_LANG || 'es')
  const [brand, setBrand] = React.useState({ title: 'MUI + CMS', links: {} })

  React.useEffect(() => {
    const ctrl = new AbortController()
    fetchSettings({ signal: ctrl.signal, locale: lang }).then(json => {
      // Try common shapes for settings (single entry collection)
      const fields = json?.fields || json
      setBrand({
        title: fields?.title || 'Site',
        links: {
          github: fields?.github,
          x: fields?.['field_45'],
          facebook: fields?.['field_46'],
          linkedin: fields?.linkedin,
        }
      })
    }).catch(() => {/* ignore settings errors */})
    return () => ctrl.abort()
  }, [lang])

  return (
    <>
      <AppBar position="sticky" sx={{ mb: 3 }}>
        <Toolbar>
          <Typography variant="h6" sx={{ flexGrow: 1 }}>{brand.title}</Typography>
          {brand.links.github && (
            <IconButton color="inherit" component="a" href={brand.links.github} target="_blank" rel="noreferrer" aria-label="GitHub">
              <GitHubIcon />
            </IconButton>
          )}
          <LanguageMenu value={lang} onChange={setLang} options={['es','en']} />
        </Toolbar>
      </AppBar>

      <Container maxWidth="lg" sx={{ pb: 6 }}>
        <Typography variant="h4" sx={{ mb: 2, fontWeight: 700 }}>Últimos posts</Typography>
        <PostsGrid locale={lang} />

        <Box sx={{ mt: 6, textAlign: 'center', color: 'text.secondary' }}>
          <Typography variant="body2">
            Front-end React con <MLink href="https://mui.com/material-ui/getting-started/installation/" target="_blank" rel="noreferrer">MUI</MLink> conectado a CMS multilenguaje.
          </Typography>
        </Box>
      </Container>
    </>
  )
}
